describe("测试用例",function(){
    it("测试增加点赞",function(){
        expect(window.add(1)).toBe(2);
    })
})