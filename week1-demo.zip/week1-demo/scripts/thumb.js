'use strict';

var _index = require('./index.es6');

var _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var f = new _index2.default(0, $('#thumb'));
f.clickAction();
